import cv2
import numpy as np
img=cv2.imread("pic.jpg")
threshold_value=200
_,binary_thresold=cv2.threshold(img,threshold_value,255,cv2.THRESH_BINARY)
cv2.imshow("binary_thresold",binary_thresold)
cv2.waitKey(0)
cv2.destroyAllWindows()