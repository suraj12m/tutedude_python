import cv2
img=cv2.imread('pic.jpg')
resized=cv2.resize(img,(600,600))
kernel_size=(7,7)
sigmax=0
sigmay=0
blur=cv2.GaussianBlur(resized,kernel_size,sigmax,sigmay)
cv2.imshow('Original',resized)
cv2.imshow('Blurred',blur)
cv2.waitKey(0)
cv2.destroyAllWindows()