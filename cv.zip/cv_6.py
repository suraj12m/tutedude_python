import cv2
import numpy as np
img=cv2.imread("pic.jpg")
print(img.shape)
row=img.shape[0]
col=img.shape[1]
s=np.float32([(1,0,150),(0,1,70)])
shifted=cv2.warpAffine(img,s,(col,row))
cv2.imshow("shifted",shifted)
cv2.waitKey(0)
cv2.destroyAllWindows()