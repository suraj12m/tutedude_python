import cv2
img=cv2.imread('pic.jpg')
resized=cv2.resize(img,(500,500))
kernel_size=3
blur=cv2.medianBlur(resized,kernel_size)
cv2.imshow('Original',resized)
cv2.imshow('Blurred',blur)
cv2.waitKey(0)
cv2.destroyAllWindows()