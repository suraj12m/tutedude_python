import cv2
img=cv2.imread('pic.jpg')
resized=cv2.resize(img,(600,600))
d=7
sigmacolor=100
sigmaSpace=100
blur=cv2.bilateralFilter(resized,d,sigmacolor,sigmaSpace)   
cv2.imshow('Bilateral Filter',blur)
cv2.waitKey(0)
cv2.destroyAllWindows()