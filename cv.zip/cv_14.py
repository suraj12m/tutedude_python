import cv2
video = cv2.VideoCapture("vid.mp4")
fourcc= cv2.VideoWriter_fourcc(*'mp4v')
output=cv2.VideoWriter('Output.mp4',fourcc,30.0,(1194,500))
while video.isOpened():
    ret,frame=video.read()
    if not ret:
        video.set(cv2.CAP_PROP_POS_FRAMES,0)
        continue
    if ret:
        output.write(frame)
        cv2.imshow('Frame',frame)
        if cv2.waitKey(10) == ord('s'):
            break
    else:
        break
cv2.destroyAllWindows()