import cv2
import numpy as np
img=cv2.imread("pic.jpg")
row=img.shape[1]
col=img.shape[0]
centre=(col/2,row/2)
angle=180
r=cv2.getRotationMatrix2D(centre,angle,1)
rotated=cv2.warpAffine(img,r,(col,row))
cv2.imshow("rotated",rotated)
cv2.waitKey(0)
cv2.destroyAllWindows()