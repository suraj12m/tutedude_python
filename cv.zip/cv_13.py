import cv2
video=cv2.VideoCapture("vid.mp4")

while video.isOpened():
    ret,frame=video.read()
    if not ret:
        video.set(cv2.CAP_PROP_POS_FRAMES,0)
        continue
    frame=cv2.resize(frame,(400,400))
    cv2.imshow('Video',frame)
    if cv2.waitKey(1) & 0xFF==ord('q'):
        break
cv2.destroyAllWindows()
