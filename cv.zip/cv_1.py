import cv2
img=cv2.imread("pic.jpg") # imread() --> img read takes argument img dir and if want b&w pass 0 as a second argument


print("dimensions of img : " ,img.shape)

width=400
height=400
dim=(width,height)
resized= cv2.resize(img,dim)

cv2.imshow("window",resized) # imshow() --> this funcn will open the read img 

print("dimensions of resized img : " ,resized.shape)

#cv2.imwrite('mountain.jpg',img) #imwrite() --> this help to save the img in ("loction/imgname.jpg",img)
cv2.waitKey(0) # waitKey is use to keep open the window, no. inside is in mili sec AND 0 for infinite time
cv2.destroyAllWindows()