import cv2
import numpy as np
img = cv2.imread("pic.jpg")
w = 600
h = 850
dim = (w, h)
resized = cv2.resize(img, dim)
print("size in bytes:", resized.size)
cv2.imshow("Original", resized)

flip=cv2.flip(resized, 1)
cv2.imshow("Horizontal Flip", flip)

flip_1=cv2.flip(resized, 0)
cv2.imshow("Vertical Flip", flip_1)

flip2=cv2.flip(resized, -1)
cv2.imshow("Both Flip", flip2)

cv2.waitKey(0)
cv2.destroyAllWindows()