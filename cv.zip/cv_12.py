# Canny Edge Detection
# 1. Noise Reduction
#  2. Intensity of gradient of the image
#3. Non-maximum suppression
#4. Thresholding 
import cv2
import numpy as np
img=cv2.imread('pic.jpg',0)
resized=cv2.resize(img,(500,500))
min_thresh=100
max_thresh=200
edges=cv2.Canny(resized,min_thresh,max_thresh)
cv2.imshow('Canny Edges',edges)
cv2.waitKey(0)
cv2.destroyAllWindows()
