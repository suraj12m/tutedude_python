import cv2
cap = cv2.VideoCapture(0)
while cap.isOpened():
    ret,frame=cap.read()
    if not ret:
        cap.set(cv2.CAP_PROP_POS_FRAMES,0)
        continue
    cv2.imshow('Live',frame)
    if cv2.waitKey(10) == ord('z'):
        break
cv2.destroyAllWindows()