import cv2
img= cv2.imread("pic.jpg")
print("original image shape:", img.shape)

scale=50
w=int(img.shape[1]*scale/100)
h=int(img.shape[0]*scale/100)
dim=(w,h)
resized=cv2.resize(img,dim,interpolation=cv2.INTER_AREA)
print("resized image shape:", resized.shape)
cv2.imshow("original",img)
cv2.imshow("resized",resized)
cv2.waitKey(0)
cv2.destroyAllWindows()