from ChatBot import ChatUI
server_ui=ChatUI("server")
server_ui.run()