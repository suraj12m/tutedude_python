from ChatBot import ChatUI
server_ui=ChatUI("client")
server_ui.run()