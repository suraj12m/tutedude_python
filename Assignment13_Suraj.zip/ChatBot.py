import customtkinter as ctk
import socket
from threading import Thread
class ChatUI():

    def __init__(self,role):
        self.role=role
        self.root = ctk.CTk()
        self.root.geometry("350x400")
        self.root.configure(fg_color="#111B21")
        self.root.resizable(False,False)
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("green")

        self.root.title(self.role)

        self.chat_frame=ctk.CTkScrollableFrame(self.root,width=350,height=300,fg_color="#111B21")
        self.chat_frame.pack(padx=10,pady=10,fill="both",expand=True)

        self.buttom_frame=ctk.CTkFrame(self.root,fg_color="#111B21")
        self.buttom_frame.pack(fill="x",padx=10,pady=10)

        self.entry=ctk.CTkEntry(self.buttom_frame,fg_color="#2A3942",border_width=0,text_color="white")
        self.entry.pack(side="left",fill="x",expand=True,padx=5)
        self.entry.bind("<Return>",lambda e: self.send_mess())

        self.button=ctk.CTkButton(self.buttom_frame,text="send",fg_color="#00A884",hover_color="#008F72",command=self.send_mess)
        self.button.pack(side="right",padx=5)
        

        self.connection()
        Thread(target=self.receive_msg,daemon=True).start()
    
    def connection(self):
        self.s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        HOST_NAME=socket.gethostname()
        PORT=12345
        if self.role=="server":
            self.s.bind((HOST_NAME,PORT))
            self.s.listen(4)
            self.client,self.address=self.s.accept()
        elif self.role=="client":
            self.s.connect((HOST_NAME,PORT))


    def add_msg(self,msg,side="left"):
        if side=="left":
            label=ctk.CTkLabel(self.chat_frame,text=msg,anchor="w",fg_color="#202C33",text_color="#FFFFFF",corner_radius=15,padx=15,pady=8)
            label.pack(anchor="w",padx=5,pady=3)
        else:
            label=ctk.CTkLabel(self.chat_frame,text=msg,anchor="w",fg_color="#005C4B",text_color="#FFFFFF",corner_radius=15,padx=15,pady=8)
            label.pack(anchor="e",padx=5,pady=3)
        self.chat_frame._parent_canvas.yview_moveto(1.0)

    def send_mess(self):
        msg=self.entry.get()
        if msg.strip():
            if self.role=="server":
                self.client.send(bytes(msg,'utf-8'))
            else:
                self.s.send(bytes(msg,'utf-8'))
            self.add_msg(msg,"right")
            self.entry.delete(0,"end")

    def receive_msg(self):
        while True:
            try:
                if self.role=="server":
                    msg=self.client.recv(50).decode('utf-8')
                else:
                    msg=self.s.recv(50).decode('utf-8')
                self.add_msg(msg,"left")
            except:
                break


    def run(self):
        self.root.mainloop()


