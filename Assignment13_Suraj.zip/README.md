# Socket Chat App

A simple chat application built using Python, Socket Programming, and CustomTkinter. 
It supports real-time messaging between a server and a client with a modern dark UI.

## Requirements

- Python 3.x
- customtkinter
- socket
- threading

Install dependency:

```bash
pip install customtkinter socket threading
```

## Workflow

1. Start the server .
2. Start the client.
3. Connection is established using sockets.
4. Messages are sent and received in real time.
5. Thread is used to avoid UI freezing while receiving messages.
6. Thread is used to recevie messages in background.
7. Different colors are used for sent and received messages.

## How to Run

1. Run Server
    ```bash
    python server_01.py
    ```

2. Run Client
    ```bash
    python client_01.py
    ```

## Features

- Dark Theme UI
- Real-time Chat
- Send Message with Enter Key
- Separate Colors for Sent & Received Messages
- Scrollable Chat Area
- Multi-threaded Message Receiving


## About client.py and server.py 
It works in the terminal 
 - first we run server.py
 - then we run client.py
 - The message sent from server to client 
 - Client will sent message to server
 - In this server and client will wait for each other for reciving messages

## Desclamer
- I have Not used any Ai to create this project after learning TKinter i learn about coustomTkinter and applyied OOPs in this project to stop repeatation of writting same ui code for both server and client and about threading as in lacture sir mention about this so i learn basic from youtube
