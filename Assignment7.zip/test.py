import psycopg2
def Table():
    conn=psycopg2.connect(dbname="postgres",user="postgres",password="suraj",host="localhost",port="5432")
    cursor=conn.cursor()
    cursor.execute('''create table employees(Name Text, ID int, Age int);''')
    print("Table created ")
    conn.commit()
    conn.close()

def data():
    conn=psycopg2.connect(dbname="postgres",user="postgres",password="suraj",host="localhost",port="5432")
    cursor=conn.cursor()
    cursor.execute('''insert into employees(Name,ID,Age) values('Sam',01,30);''')
    print("Data added")
    conn.commit()
    conn.close()

def data_enter():
    conn=psycopg2.connect(dbname="postgres",user="postgres",password="suraj",host="localhost",port="5432")
    cursor=conn.cursor()
    name=input("Enter name : ")
    id=input("Enter id : ")
    age=input("Enter age : ")
    query='''insert into employees(Name,ID,Age) values(%s,%s,%s);'''
    cursor.execute(query,(name,id,age))
    print("Data added successfully")
    conn.commit()
    conn.close()

def extact():
    conn=psycopg2.connect(dbname="postgres",user="postgres",password="suraj",host="localhost",port="5432")
    cursor=conn.cursor()
    cursor.execute('''select * from employees;''')
    print(cursor.fetchone())
    conn.commit()
    conn.close()


