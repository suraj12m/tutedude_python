# How to Run

1. Install psycopg2:
   pip install psycopg2

2. Make sure PostgreSQL is running

3. Check your database credentials (dbname, user, password, host, port)

4. Open terminal in project folder

5. Run the file:
   python test.py

Note:
- First, the table will be created
- Then data will be inserted
- Then data will be fetched