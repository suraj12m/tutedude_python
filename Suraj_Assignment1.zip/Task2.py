n1=input("Enter User First Name : ")
n2=input("Enter User Second Name : ")
print("Hello",n1+" "+ n2,"! Welcome to python program")