a=int(input("Enter the First Number :"))
b=int(input("Enter the Second Number :"))
add=a+b
sub=a-b
div=a/b
mul=a*b
print("Addition :", add)
print("subtraction:", sub)
print("Multiplication:", mul)
print("Division :", div)