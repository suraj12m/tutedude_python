# 📘 Python Assignment 3

## 📌 Overview
This project contains two Python programs using functions and the math module:
1. Calculate **Factorial using Recursion**
2. Perform mathematical operations using the **math module**

---

## 📂 Files Included

- `task1.py` → Factorial using recursion  
- `task2.py` → Square root, logarithm, and sine using math module  

---

## ▶️ How to Run the Programs

### 🔧 Requirements
- Python 3.x installed

### 🚀 Steps

```bash
cd Assignment3
python task1.py
python task2.py