l=[1,2,3,4,5,6,7,8,9,10]
print(f" Extracted first five element : {l[0:5]}")
print(f" Reversed Extracted element : {list(reversed(l[0:5]))}")
