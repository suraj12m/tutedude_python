# Python Tasks - README

## Overview
This repository contains two simple Python programs demonstrating:

1. Dictionary lookup with exception handling.
2. List slicing and reversing.

---

## Task 1: Student Marks Lookup

### Description
This program stores student names and their marks in a dictionary. It asks the user to enter a student's name and displays the corresponding marks. If the student is not found, an error message is shown using exception handling.

### Code

```python
students = {
    'Suraj': 89,
    'Apu': 90,
}

name = input("Enter the student's name : ")

try:
    print(f"{name}'s marks : {students[name]}")
except:
    print("Student not found")
```

### Sample Output

**Input:**
```
Enter the student's name : Suraj
```

**Output:**
```
Suraj's marks : 89
```

**Input:**
```
Enter the student's name : Rahul
```

**Output:**
```
Student not found
```

### Concepts Used
- Dictionary
- User Input
- Exception Handling (`try-except`)

---

## Task 2: List Slicing and Reversing

### Description
This program creates a list of numbers from 1 to 10, extracts the first five elements, and then displays the extracted elements in reverse order.

### Code

```python
l = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

print(f"Extracted first five elements : {l[0:5]}")
print(f"Reversed extracted elements : {list(reversed(l[0:5]))}")
```

### Sample Output

```
Extracted first five elements : [1, 2, 3, 4, 5]
Reversed extracted elements : [5, 4, 3, 2, 1]
```

### Concepts Used
- Lists
- List Slicing
- `reversed()` Function
- List Conversion

---

## Requirements

- Python 3.x

## How to Run

1. Save the code in a Python file (`.py`).
2. Open a terminal or command prompt.
3. Run the file using:

```bash
python filename.py
```

## Learning Outcomes

After completing these tasks, you will learn:
- How to use dictionaries for data storage and retrieval.
- How to handle exceptions using `try-except`.
- How to extract elements from a list using slicing.
- How to reverse list elements in Python.