students={
    'Suraj':89,
    'Apu':90,
}
name=input("Enter the student's name : ")

try:
    print(f"{name}'s marks : {students[name]}")
except:
    print("Student not found")