## Web Scraping using python
Extracts Product Details from Amazon

## Requirements
- Requests
- BeautifulSoup

## Installation
```bash
pip install -r requirements.txt
```
## Explaination
Created a class Product 
contains init funtion to 
 - receive url 
 - initized the User-Agent 
 - response to request to get url response in text form
 - soup (BeautifulSoup) to get html page from response


 ```python
  def __init__(self,url):
        self.url=url
        self.user={"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36"}
        self.response=requests.get(url=self.url,headers=self.user).text
        self.soup=BeautifulSoup(self.response,'lxml')
```

Function inside class are :-
 - ProductName ~ to get Product Name 
    ```python
        title=self.soup.find("span",{"id":"productTitle"})
    ```
 - ProductPrice ~ to get Product Price
    ```python
        price=self.soup.find("span",{"class":"a-price-whole"})
        pr=int(price.text.strip('.').replace(',',''))
    ```
 - ProductRate ~ to get Product Rate
    ```python
        rate=self.soup.find("span",{"class":"a-size-small a-color-base"})
    ```
 - ProductImg ~ to get Product Img Link and Download
    ```python
        img=self.soup.find("img",{"id":"landingImage"})
        title=self.soup.find("span",{"id":"productTitle"}).text.strip()
    ```
    - To save img
    ```python  
        img_url=img.get("src")
        res=requests.get(img_url)
        with open(f"{title}.jpg","wb") as f:
            f.write(res.content)
    ```

- Using Funtion getall which accept url_list and target
    - call the class 
    - Print all details from urls
    - Compair the product prize with target
    ```python
    def getall(url_list,target):
        for url in url_list:
            p=product(url=url)
            print(f" {p.ProductName()} \n {p.ProductRate()} \n {p.ProductImg()} \n  {p.ProductPrice()[0]} \n")
            if(p.ProductPrice()[1]>target):
                print(f"{p.ProductName()} Prize is more than target prize")
    ```

## How to RUN
- Run this command in terminal
```bash
    python AmazonProduct.py
```
- Give input your Target prize

## Tips
- You can try by changing url by adding url_list

