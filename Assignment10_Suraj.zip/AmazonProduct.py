import requests
from bs4 import BeautifulSoup
class product:
    def __init__(self,url):
        self.url=url
        self.user={"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36"}
        self.response=requests.get(url=self.url,headers=self.user).text
        self.soup=BeautifulSoup(self.response,'lxml')

    def ProductName(self):
        title=self.soup.find("span",{"id":"productTitle"})
        if title is not None:
            return f"Product Name : {title.text.strip()}"
        else:
            return "Title NOT Found"
        
    def ProductPrice(self):
        price=self.soup.find("span",{"class":"a-price-whole"})
        pr=int(price.text.strip('.').replace(',',''))
        if price is not None:
            return (f"Price : ₹{pr}",pr)
        else:
            return "Price NOT Found"
        
    def ProductRate(self):
        rate=self.soup.find("span",{"class":"a-size-small a-color-base"})
        if rate is not None:
            return f"Rate : {rate.text.strip()}/5.0"
        else:
            return "Rate NOT Found"
    
    def ProductImg(self):
        img=self.soup.find("img",{"id":"landingImage"})
        title=self.soup.find("span",{"id":"productTitle"}).text.strip()
        if img is not None:
            img_url=img.get("src")
            res=requests.get(img_url)
            with open(f"{title}.jpg","wb") as f:
                f.write(res.content)
            return f"Image url : {img_url}"
        else:
            return "Title NOT Found"

def getall(url_list,target):
    for url in url_list:
        p=product(url=url)
        print(f" {p.ProductName()} \n {p.ProductRate()} \n {p.ProductImg()} \n {p.ProductPrice()[0]} \n")
        if(p.ProductPrice()[1]>target):
            print(f"{p.ProductName()} Prize is more than target prize")

url1="https://www.amazon.in/Samsung-Awesome-Lavender-Nightography-Upgrades/dp/B0GS18DH5P/ref=pd_sbs_d_sccl_1_4/525-8873301-2771901?pd_rd_w=FLcQQ&content-id=amzn1.sym.d1406b44-aa69-47e4-9270-f613e12d52dc&pf_rd_p=d1406b44-aa69-47e4-9270-f613e12d52dc&pf_rd_r=W26G5A15TV0ZWMAZJYV1&pd_rd_wg=5IYMp&pd_rd_r=5e37a6e7-6b2d-4966-9c21-f6a9b1d74740&pd_rd_i=B0GS18DH5P&th=1"
url2="https://www.amazon.in/Samsung-Galaxy-Smartphone-128GB-Storage/dp/B0DHL98QM2/ref=sr_1_1?crid=3P97KP9Q1O9TX&dib=eyJ2IjoiMSJ9.r41AOi2dGq6-cLKsZnI0rctqfTn2yliOkUI-uYl1f5ow5hBJ7YMZMPY23YXxuptPjG9A6L59BlLle2IH_Tp6jfIbI_gSlU1AK6kKpuHHuT49wyxfm2RzwqXyOvYbLPI4pYnGgGa6zRoluZRPwy2pUfh6HcvebxotCGxyBqlHl8Tgw-Fd5ppa56oMphI3mQOzN_m6oOQ9N_ybuUQ1arueezPPi4ikYEnKZ6pZFDl1ce8.5qJysiBa3aK0U79gFVJP3bGorAC837fayEhEERfw-jU&dib_tag=se&keywords=samsung+s24fe&qid=1781780115&sprefix=sumsung+s24fe%2Caps%2C341&sr=8-1"
url3="https://www.amazon.in/Samsung-Smartphone-JetBlack-Storage-ProVisual/dp/B0FNMQW9HW/ref=pd_sbs_d_sccl_1_1/525-8873301-2771901?pd_rd_w=jcqpq&content-id=amzn1.sym.d1406b44-aa69-47e4-9270-f613e12d52dc&pf_rd_p=d1406b44-aa69-47e4-9270-f613e12d52dc&pf_rd_r=XAF3YEJE4VPC4SCAQ1XK&pd_rd_wg=Jk3u1&pd_rd_r=f075d418-6bb9-4acd-908a-ce6d7c27bbc8&pd_rd_i=B0FNMQW9HW&th=1"
url_list=[url1,url2,url3]
target=int(input("Enter Target Price  : "))
getall(url_list,target=target)
