## Assignment 4 - FileHandiling

## Task 1
1. Read the sample.txt and print line by line 
2. TO open file in readin mode use " with open('sample.txt','r') as file"
3. Using try for file not found exception error
4. By applying loop in file and read line by line and print it 

## Task 2
We have to write and then append the data in same file
1. we take data input and then write it in file by using "with open("output.txt","w") as file" and  file.write(text + "\n")
2. We take new data which we want to append in same file 
3. we append the data using 
    with open("output.txt","a") as file:
        file.write(add_text)