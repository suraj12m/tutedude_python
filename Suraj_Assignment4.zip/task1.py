try:
    with open('sample.txt','r') as file:
        i=1
        print("Reading File content")
        for line in file:
            print(f"Line {i} : {line.strip()}")
            i+=1
except  FileNotFoundError :
    print("The file 'sample.txt' not found")