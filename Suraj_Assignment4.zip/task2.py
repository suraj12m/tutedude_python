text=input("Enter text to write to file: ")

with open("output.txt","w") as file:
    file.write(text + "\n")
print("Data successfully written to output.txt")

add_text=input("Enter additional text to append : ")
with open("output.txt","a") as file:
    file.write(add_text)
print("Data Successfully appended.")

print("Final Content of output.txt")
with open("output.txt","r") as file:
    for line in file:
        print(line, end="")