# Amazon Selenium Automation

Automates product search and basic interactions on Amazon using Selenium WebDriver.

## Requirements

* Python 3.x
* Selenium
* Google Chrome
* ChromeDriver

## Workflow

* Open Amazon India
* Search for "Laptop"
* Refresh the page
* Print navigation menu items
* Extract product names
* Open the first product
* Switch to the new tab
* Add the product to the cart
* Navigate to the Mobiles section
* Search for "Samsung S24"
* Close the browser

## How to Run

```bash
pip install selenium
```

```bash
python selenium_auto.py
```
