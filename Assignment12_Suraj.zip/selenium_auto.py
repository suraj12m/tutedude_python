from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import time

driver=webdriver.Chrome()
driver.get("https://www.amazon.in/")
driver.maximize_window()

time.sleep(2)
search_box=driver.find_element(By.ID,"twotabsearchtextbox")
search_box.send_keys("Laptop")
search_box.send_keys(Keys.ENTER)
time.sleep(5)

driver.refresh()
time.sleep(3)

menu=driver.find_elements(By.CLASS_NAME,"nav-a")
for m in menu:
    print(m.text)

print(driver.title)

products=driver.find_elements(By.XPATH,"//h2[@class='a-size-medium a-spacing-none a-color-base a-text-normal']")
print(f"Found : {len(products)}")

for p in products[:10]:
    print(p.text,"\n")

first_product=driver.find_element(By.XPATH,"//h2[@class='a-size-medium a-spacing-none a-color-base a-text-normal']")
first_product.click()
time.sleep(3)

driver.switch_to.window(driver.window_handles[-1])
time.sleep(3)

buy_now=driver.find_element(By.ID,"add-to-cart-button")
buy_now.click()

mobiles=driver.find_element(By.LINK_TEXT,"Mobiles").click()
time.sleep(2)

search_boxx=driver.find_element(By.NAME,"field-keywords")
search_boxx.send_keys("Sumsung S24")
search_boxx.send_keys(Keys.ENTER)
time.sleep(2)

n=input()
driver.quit()