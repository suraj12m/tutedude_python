# User Profile REST API

## Features

- Create User
- List Users
- Retrieve User
- Update User
- Delete User

## Installation

```bash
pip install -r requirements.txt
```

## Run Server

```bash
python manage.py runserver
```

## API Endpoints

### Get all users / Create user

```text
/api/users/
```

### Retrieve / Update / Delete user

```text
/api/users/<id>/
```

## Example JSON

```json
{
    "name": "Suraj Mandal",
    "email": "suraj@gmail.com",
    "phone_number": "1234567890",
    "bio": "Python Developer"
}
```