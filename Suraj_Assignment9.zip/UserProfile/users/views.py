from django.shortcuts import render
from rest_framework import generics
from users.models import UserProfile
from users.serializers import UserProfileSerializer
# Create your views here.

class UserListCreateView(generics.ListCreateAPIView):
    queryset = UserProfile.objects.all()
    serializer_class = UserProfileSerializer

class UserDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = UserProfile.objects.all()
    serializer_class = UserProfileSerializer