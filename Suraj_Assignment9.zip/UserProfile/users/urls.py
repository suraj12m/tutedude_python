from django.urls import path
from users import views
from users.views import UserListCreateView, UserDetailView

urlpatterns = [
    path('users/', UserListCreateView.as_view()),
    path('users/<int:pk>/', UserDetailView.as_view()),
]
