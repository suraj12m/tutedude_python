# 📝 Flask Registration Form Project

## 📌 Project Description
This is a simple Flask web application that takes user input (Name, City, Phone Number) through a registration form and displays the submitted data on a confirmation page.

---

## 🚀 Features
- User Registration Form  
- Accepts Name, City, Phone Number  
- Displays submitted data on confirmation page  
- Built using Flask and HTML  

---

## 🛠️ Technologies Used
- Python 🐍  
- Flask 🌐  
- HTML 📄  

---

## 📂 Project Structure
Assignment11/
│── new.py
│── templates/
│   ├── register.html
│   └── conformation.html

---

## ▶️ How to Run

1. Install Flask  
pip install flask  

2. Run the application  
python new.py  

3. Open browser and go to  
http://127.0.0.1:5000/register  

---

## 📸 Output

### Registration Page
User enters Name, City, Phone  

### Confirmation Page
Displays submitted data:

NAME  : <name>  
CITY  : <city>  
PHONE : <phone>  

---

## 💡 How It Works
- `/register` route handles both GET and POST requests  
- Form submits data using POST method  
- Data is fetched using `request.form.get()`  
- Data is passed to `conformation.html` using `render_template()`  

---

## ⚠️ Note
- Make sure templates folder is in correct location  
- File name should be exactly: conformation.html  

---

