from flask import Flask ,render_template, request
web=Flask(__name__)

@web.route("/")
def home():
    return "<H1>Registration form<H1>"

@web.route("/register", methods=['POST','GET'])
def register():
    if request.method =="POST":
        n=request.form.get('name')
        c=request.form.get('city')
        p=request.form.get('phone')
        return render_template('conformation.html',name=n,city=c,phone=p)

    return render_template('register.html')


if __name__ == "__main__":
    web.run(debug=True)