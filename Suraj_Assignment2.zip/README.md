# 📘 Python Assignment 2

## 📌 Overview
This project contains two basic Python programs:
1. Check whether a number is **even or odd**
2. Find the **sum of numbers from 1 to 50**

---

## 📂 Files Included

- `task1.py` → Even or Odd checker  
- `task2.py` → Sum of numbers from 1 to 50  

---

## ▶️ How to Run the Programs

### 🔧 Requirements
- Python 3.x installed

### 🚀 Steps

```bash
cd Assignment2
python task1.py
python task2.py