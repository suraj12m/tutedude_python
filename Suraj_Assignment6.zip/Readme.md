# 🧮 Tkinter Calculator App

A simple calculator application built using Python's Tkinter library. It supports basic arithmetic operations with a clean graphical interface.

---

## 🚀 Features

- Addition, Subtraction, Multiplication, Division
- Clear (C) button
- Backspace (X) button
- Decimal support
- User-friendly UI

---

## 🛠️ Tech Stack

- Python
- Tkinter (GUI Library)

---

## ▶️ How to Run

### Step 1: Install Python
Make sure Python is installed.

```bash
python --version