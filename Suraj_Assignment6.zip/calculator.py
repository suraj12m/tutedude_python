from tkinter import *
root=Tk()
root.title("Calculator")
root.geometry("400x422")
root.minsize(400,422)
root.maxsize(400,422)
def click(text):
    if text=="=":
            try:
                ans=eval(data.get())
                data.set(ans)
            except:
                data.set("")
    elif text=="C":
        data.set("")   
    elif text=="X":
        data.set(data.get()[:-1])
    else:
        data.set(data.get()+text)

# entry box
data=StringVar()
data.set("")
e=Entry(root,font=("Arial",30,"bold"),borderwidth=5,width=17,textvariable=data, justify="right")
e.place(x=0,y=0)

# buttons
b=Button(root,text="7",font=("Arial",25,"bold"),width=4,command=lambda x='7': click(x))
b.place(x=8,y=70)

b=Button(root,text="8",font=("Arial",25,"bold"),width=4,command=lambda x='8': click(x))
b.place(x=98,y=70)

b=Button(root,text="9",font=("Arial",25,"bold"),width=4,command=lambda x='9': click(x))
b.place(x=188,y=70)

b=Button(root,text="4",font=("Arial",25,"bold"),width=4,command=lambda x='4': click(x))
b.place(x=8,y=140)

b=Button(root,text="5",font=("Arial",25,"bold"),width=4,command=lambda x='5': click(x))
b.place(x=98,y=140)

b=Button(root,text="6",font=("Arial",25,"bold"),width=4,command=lambda x='6': click(x))
b.place(x=188,y=140)


b=Button(root,text="1",font=("Arial",25,"bold"),width=4,command=lambda x='1': click(x))
b.place(x=8,y=210)

b=Button(root,text="2",font=("Arial",25,"bold"),width=4,command=lambda x='2': click(x))
b.place(x=98,y=210)

b=Button(root,text="3",font=("Arial",25,"bold"),width=4,command=lambda x='3': click(x))
b.place(x=188,y=210)

b=Button(root,text="C",font=("Arial",25,"bold"),width=4,command=lambda x='C': click(x))
b.place(x=8,y=280)

b=Button(root,text="0",font=("Arial",25,"bold"),width=4,command=lambda x='0': click(x))
b.place(x=98,y=280)

b=Button(root,text=".",font=("Arial",25,"bold"),width=4,command=lambda x='.': click(x))
b.place(x=188,y=280)

b=Button(root,text="=",font=("Arial",25,"bold"),width=12,command=lambda x='=': click(x))
b.place(x=8,y=350)

b=Button(root,text="X",font=("Arial",25,"bold"),width=4,command=lambda x='X': click(x))
b.place(x=278,y=350)

b=Button(root,text="/",font=("Arial",25,"bold"),width=4,command=lambda x='/': click(x))
b.place(x=278,y=70)

b=Button(root,text="+",font=("Arial",25,"bold"),width=4,command=lambda x='+': click(x))
b.place(x=278,y=140)
b=Button(root,text="-",font=("Arial",25,"bold"),width=4,command=lambda x='-': click(x))
b.place(x=278,y=210)
b=Button(root,text="*",font=("Arial",25,"bold"),width=4,command=lambda x='*': click(x))
b.place(x=278,y=280)


root.mainloop()